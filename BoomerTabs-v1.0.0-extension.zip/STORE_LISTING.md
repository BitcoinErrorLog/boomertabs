# BoomerTabs Chrome Web Store Listing Draft

## One-line summary

BoomerTabs gives you bigger, easier-to-scan tab rows with multi-row layouts, drag-and-drop reordering, and fast keyboard navigation.

## Short description (132 chars max)

Large multi-row tab tiles with drag-and-drop, groups, search, and footer/header layouts for heavy tab users.

## Detailed description

BoomerTabs is built for people who keep many tabs open and need a cleaner, faster way to navigate.

Key capabilities:

- Multi-row tab layouts with configurable row count
- Adjustable tabs-per-row, tab width, icon size, label size, and padding
- Drag-and-drop tab reordering directly in the custom rows
- Group-aware tabs with collapse support and clear group color markers
- Search and filter tabs by title or URL
- Search icon toggle that shows/hides a dedicated search row
- Footer or header placement
- Overlay mode and push mode (push avoids page overlap)
- Per-row horizontal scrolling (mouse wheel + trackpad gestures)
- Hidden scrollbar UI (keeps more vertical room for tabs/content)
- Pinned-tab handling with optional icon-only pinned tabs
- Quick hide/show controls and keyboard shortcuts
- Toolbar popup quick controls for layout/rows/groups without opening full settings

Privacy:

- No external analytics
- No data sold or transmitted to third parties
- Settings stored locally in extension storage

## Screenshot assets

- `store-assets/cws/screenshot-01-1280x800.jpg`
- `store-assets/cws/screenshot-02-1280x800.jpg`
- `store-assets/cws/screenshot-03-1280x800.jpg`

## Promo icon source

- `store-assets/icon-base.png`
- `store-assets/icon-128.png` (Chrome Web Store icon upload)

## Optional promo tiles

- Small promo tile: `store-assets/cws/small-promo-440x280.jpg`
- Marquee promo tile: `store-assets/cws/marquee-promo-1400x560.jpg`
- Large promo tile: `store-assets/cws/large-promo-920x680.jpg`

## Support metadata (fill in before submit)

- Support email: `YOUR_SUPPORT_EMAIL`
- Support website: `YOUR_SUPPORT_URL`
