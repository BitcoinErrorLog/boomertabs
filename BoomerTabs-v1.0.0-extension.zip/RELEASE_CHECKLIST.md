# BoomerTabs Release Checklist

Status: launch-ready package complete. One store-field remains user-specific (support email/website).

## Functional QA

- [x] Load unpacked extension successfully in `chrome://extensions`
- [x] Verify overlay appears on `http://` and `https://` pages
- [x] Verify no overlay on restricted pages (`chrome://*`)
- [x] Verify row count + tabs-per-row settings apply correctly
- [x] Verify each row scrolls horizontally with wheel and trackpad
- [x] Verify group headers, group collapse, and group colors
- [x] Verify pinned tabs ordering and pinned icon-only mode
- [x] Verify search/filter behavior and clear state
- [x] Verify search-row toggle icon behavior (show/hide dedicated search row)
- [x] Verify keyboard actions (`Left/Right`, `Enter`, `Delete`)
- [x] Verify quick hide/show button and hotkey (`Alt+Shift+B`)
- [x] Verify auto-hide and edge activation settings
- [x] Verify horizontal scroll works with hidden scrollbar UI

## Performance QA

- [x] Open 50+ tabs and verify smooth render/scroll
- [x] Open 100+ tabs and verify no major lag/hang
- [x] Verify rapid tab create/close/update events remain responsive

## Accessibility QA

- [x] Ensure visible focus on selected tab
- [x] Ensure buttons/inputs have accessible labels
- [x] Verify reduced-motion behavior (`prefers-reduced-motion`)

## Packaging

- [x] Confirm icon assets exist (`16`, `48`, `128`)
- [x] Confirm `manifest.json` name/version/description are final
- [x] Confirm `README.md` is accurate
- [x] Confirm `PRIVACY.md` is suitable for listing

## Store Submission Prep

- [x] Prepare screenshots and short demo GIF/video
- [x] Prepare concise listing description and feature bullets
- [ ] Add support email / website in listing metadata

Notes:

- Store screenshot assets prepared in `store-assets/`.
- Listing copy prepared in `STORE_LISTING.md`.
- Upload package prepared: `../BoomerTabs-v1.0.0-extension.zip`.
- Set support metadata values in `STORE_LISTING.md` before final Chrome Web Store submit.
